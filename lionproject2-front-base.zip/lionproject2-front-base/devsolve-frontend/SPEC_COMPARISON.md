# 기능정의서 vs 현재 화면 비교 분석

## 요약

전체적으로 기능정의서의 핵심 기능들은 구현되어 있으나, **용어/표현의 불일치**와 **일부 누락된 기능**이 있습니다.

---

## 1. 용어/표현 불일치 목록

| 구분 | 기능정의서 | 현재 화면 | 파일 | 수정 필요 |
|------|-----------|----------|------|-----------|
| 멘토 목록 | "멘토 목록 조회" | "나의 멘토 찾기" | TutorialListPage.tsx | 표현 일관성 검토 |
| 버튼 텍스트 | "수업 신청" | "세션 예약" | TutorialListPage.tsx:215 | ✅ 수정 필요 |
| 사용자 수 | "{mentor.reviewCount}명의 누적 수강생" | 리뷰 수를 수강생 수로 표시 | MentorDetailPage.tsx:295 | 의미 혼동 가능 |
| 과외 용어 | "과외 (Tutorial)" | "튜토리얼" | MentorDetailPage.tsx:229 | 일관성 검토 |
| 대시보드 | "수업 요청" | "새로운 요청" | MentorDashboardPage.tsx:103 | OK (비슷함) |
| 새 과외 등록 링크 | `/tutorial/create` | `/tutoring/new` | MentorDashboardPage.tsx:34 | ✅ 수정 필요 |
| Q&A | "수업(Lesson) 기반 질문" | "수업 Q&A" | QnAListPage.tsx | OK |
| 질문 작성 링크 | `/qna/create` | `/qna/new` | QnAListPage.tsx:143 | ✅ 수정 필요 |

---

## 2. API 명세와의 불일치

### 2.1 멘토 API
| API 명세 | 현재 상태 | 비고 |
|---------|----------|------|
| GET `/api/mentors` | ✅ MentorListPage에서 사용 예정 | 현재 Mock 데이터 |
| GET `/api/mentors/{mentorId}` | ✅ MentorDetailPage에서 사용 예정 | 현재 Mock 데이터 |
| POST `/api/mentors/apply` | ✅ MentorApplicationPage 있음 | |

### 2.2 과외 API
| API 명세 | 현재 상태 | 비고 |
|---------|----------|------|
| GET `/api/tutorials` | ✅ 화면에 표시됨 | |
| GET `/api/tutorials/{tutorialId}` | ✅ TutorialDetailPage 있음 | |
| POST `/api/tutorials` | ❌ 링크 경로 불일치 | `/tutoring/new` → `/tutorial/create` |
| PUT/DELETE | ✅ TutorialFormPage 있음 | |

### 2.3 수업(Lesson) API
| API 명세 | 현재 상태 | 비고 |
|---------|----------|------|
| POST `/api/lessons` (수업 신청) | ✅ TutorialDetailPage Dialog | |
| GET `/api/lessons` (목록) | ⚠️ 대시보드에 표시 | 별도 페이지 없음 |
| PUT `/api/lessons/{id}/accept` | ⚠️ 대시보드에 버튼 없음 | 수락/거절 UI 필요 |
| PUT `/api/lessons/{id}/reject` | ⚠️ 대시보드에 버튼 없음 | |
| PUT `/api/lessons/{id}/complete` | ⚠️ UI 없음 | 수업 완료 버튼 필요 |

### 2.4 질문/답변 API
| API 명세 | 현재 상태 | 비고 |
|---------|----------|------|
| POST `/api/lessons/{lessonId}/questions` | ⚠️ 링크 경로 불일치 | `/qna/new` → `/qna/create` |
| GET `/api/lessons/{lessonId}/questions` | ✅ QnAListPage | |
| GET `/api/questions/{questionId}` | ✅ QuestionDetailPage | |
| POST `/api/questions/{questionId}/answers` | ✅ QuestionDetailPage | |

### 2.5 결제 API
| API 명세 | 현재 상태 | 비고 |
|---------|----------|------|
| POST `/api/payments` | ✅ PaymentPage | |
| POST `/api/payments/confirm` | ✅ PaymentCompletePage | |
| GET `/api/payments` | ✅ PaymentHistoryPage | |

---

## 3. 수업 상태 흐름 구현 검토

기능정의서의 수업 상태 흐름:
```
PENDING → (멘토 수락) → ACCEPTED → (결제 완료) → IN_PROGRESS → (완료) → COMPLETED
         (멘토 거절) → REJECTED
```

### 현재 구현 상태:
| 상태 | UI 구현 | 비고 |
|------|---------|------|
| PENDING | ✅ 수업 신청 시 생성 | TutorialDetailPage Dialog |
| ACCEPTED | ⚠️ 멘토 대시보드에 수락 버튼 없음 | **추가 필요** |
| REJECTED | ⚠️ 멘토 대시보드에 거절 버튼 없음 | **추가 필요** |
| IN_PROGRESS | ✅ 대시보드에 "진행중" 표시 | |
| COMPLETED | ⚠️ 완료 처리 버튼 없음 | **추가 필요** |

---

## 4. 누락된 기능/페이지

### 4.1 MVP 필수 기능 중 누락된 UI
1. **수업 수락/거절 기능** - 멘토 대시보드에서 신청된 수업을 수락/거절하는 버튼 없음
2. **수업 완료 처리** - 진행중인 수업을 완료 처리하는 UI 없음
3. **수업 상세 페이지** - `/lessons/{lessonId}` 개별 수업 상세 페이지 없음

### 4.2 확장 기능 (현재 미구현 - OK)
- 리뷰 작성 페이지
- 멘토 승인/거절 (관리자)
- 알림 기능

---

## 5. 즉시 수정이 필요한 항목

### 5.1 링크 경로 수정
```tsx
// MentorDashboardPage.tsx:34
- to="/tutoring/new"
+ to="/tutorial/create"

// QnAListPage.tsx:143
- to="/qna/new"
+ to="/qna/create"
```

### 5.2 버튼 텍스트 수정
```tsx
// TutorialListPage.tsx:215
- 세션 예약
+ 수업 신청
```

### 5.3 추가해야 할 기능
1. 멘토 대시보드에 수업 신청 수락/거절 버튼 추가
2. 수업 완료 처리 버튼 추가
3. (선택) 수업 상세 페이지 추가

---

## 6. ERD vs types/index.ts 비교

### 6.1 프론트엔드 UI에 필요하나 ERD에 없는 항목 (백엔드 요청)

| 테이블 | 컬럼 | UI 필요 이유 | 상태 |
|--------|------|-------------|------|
| `answers` | `mentor_id` | 답변 작성자 표시 | 📋 **백엔드 요청** |
| `answers` | `is_accepted` | 채택된 답변 표시 | 📋 **백엔드 요청** |
| `users` | `profile_image` | 프로필 이미지 표시 | 📋 **백엔드 요청** |

> 자세한 내용은 [BACKEND_REQUEST.md](./BACKEND_REQUEST.md) 참고

### 6.2 수정 완료 항목 ✅

| 항목 | 변경 내용 | 상태 |
|------|----------|------|
| `Lesson.scheduledAt` | optional → required | ✅ 완료 |
| `/tutoring/new` → `/tutorial/create` | 링크 경로 통일 | ✅ 완료 |
| `/qna/new` → `/qna/create` | 링크 경로 통일 | ✅ 완료 |
| "세션 예약" → "수업 신청" | 텍스트 통일 | ✅ 완료 |

### 6.3 일치 항목

| 테이블 | ERD | types/index.ts | 상태 |
|--------|-----|----------------|------|
| `users` | ✅ | ✅ User | OK |
| `mentors` | ✅ | ✅ Mentor | OK |
| `skills` | ✅ | ✅ Skill | OK |
| `tutorials` | ✅ | ✅ Tutorial | OK |
| `lessons` | ✅ | ✅ Lesson | OK |
| `questions` | ✅ | ✅ Question | OK |
| `answers` | ⚠️ | ✅ Answer | 백엔드 요청 |
| `payments` | ✅ | ✅ Payment | OK |
| `reviews` | ✅ | ✅ Review | OK |

### 6.4 ERD에만 있는 테이블 (프론트 타입 불필요)

- `refresh_token_storage` - 백엔드 전용
- `mentor_skills` - 조인 테이블 (Mentor.skills로 처리)
- `tutorial_skills` - 조인 테이블 (Tutorial.skills로 처리)

### 6.5 수업 상태(LessonStatus) 일치 확인 ✅

| ERD 주석 | types/index.ts | 상태 |
|----------|----------------|------|
| PENDING | ✅ | OK |
| APPROVED | ✅ | OK |
| REJECTED | ✅ | OK |
| IN_PROGRESS | ✅ | OK |
| COMPLETED | ✅ | OK |
| CANCELLED | ✅ | OK |

---

## 7. 권장 수정 우선순위

### 높음 (즉시 수정)
1. 링크 경로 통일 (`/tutoring/new` → `/tutorial/create`, `/qna/new` → `/qna/create`)
2. "세션 예약" → "수업 신청" 텍스트 변경

### 중간 (기능 추가)
1. 멘토 대시보드에 수업 신청 수락/거절 UI 추가
2. 수업 완료 처리 기능 추가

### 낮음 (개선)
1. 용어 일관성 검토 ("튜토리얼" vs "과외")
2. 수업 상세 페이지 추가
